import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Upload, Image as ImageIcon, Check, Camera, X, MapPin, Loader2, GripVertical, Video, AlertCircle } from "lucide-react";
import { useState, useRef, useEffect, useCallback } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/lib/auth";
import { useUpload } from "@workspace/object-storage-web";
import { GoogleMap, StandaloneSearchBox, useJsApiLoader } from "@react-google-maps/api";
import { AdvancedMarker } from "@/components/ui/AdvancedMarker";

const GOOGLE_API_KEY = import.meta.env.VITE_GOOGLE_API_KEY as string;
const GOOGLE_MAPS_LIBRARIES: ["places", "marker"] = ["places", "marker"];
const NAIROBI_CENTER = { lat: -1.2921, lng: 36.8219 };

function getImageDisplayUrl(objectPath: string): string {
  if (objectPath.startsWith("/objects/")) {
    return `/api/storage${objectPath}`;
  }
  if (objectPath.startsWith("http")) {
    return objectPath;
  }
  return `/api${objectPath}`;
}

const UNIT_AMENITIES = [
  { id: "instant_shower", label: "Instant shower" },
  { id: "study_desk", label: "Study desk" },
  { id: "safe", label: "Safe" },
  { id: "babycot", label: "Baby court" },
  { id: "housekeeping", label: "Daily housekeeping" },
  { id: "private_chef", label: "Private chef (additional)" },
  { id: "hairdryer", label: "Hair dryer" },
  { id: "ironbox", label: "Iron box" },
  { id: "wifi", label: "WiFi" },
  { id: "laundry", label: "Laundry area" },
  { id: "balcony", label: "Balcony" },
  { id: "ac", label: "Air conditioner" },
  { id: "smoker_alert", label: "Smoker alerts" },
  { id: "fridge", label: "Fridge" },
  { id: "microwave", label: "Microwave" },
  { id: "dishwasher", label: "Dishwasher" },
  { id: "coffee", label: "Coffee maker/kettle" },
  { id: "smart_tv", label: "Smart TV" },
  { id: "smoking_allowed", label: "Smoking allowed" },
  { id: "no_smoking", label: "Smoking not allowed" },
  { id: "self_locking", label: "Self locking/keylocker" }
];

const PREMISE_AMENITIES = [
  { id: "gym", label: "Gym" },
  { id: "borewater", label: "Borehole water" },
  { id: "garden", label: "Garden" },
  { id: "cctv", label: "CCTV" },
  { id: "parking", label: "Parking" },
  { id: "security", label: "24/7 security" },
  { id: "elevator", label: "Elevator" },
  { id: "electric_fence", label: "Electric fence" },
  { id: "solar", label: "Solar water heating" },
  { id: "pool", label: "Swimming pool" },
  { id: "smoking_area", label: "Smoking area" },
  { id: "generator", label: "Backup generator" },
  { id: "pet_friendly", label: "Pet friendly" },
  { id: "dsq", label: "DSQ" }
];

type ApiPropertyType = "rent" | "sale" | "bnb" | "hotel" | "hostel";

function toApiType(raw: string): ApiPropertyType {
  if (raw === "sale") return "sale";
  if (raw === "bnb") return "bnb";
  if (raw === "hotel") return "hotel";
  if (raw === "hostel") return "hostel";
  return "rent";
}

function getEditId(): string | null {
  const searchParams = new URLSearchParams(window.location.search);
  if (searchParams.has("edit")) return searchParams.get("edit");
  const hashParts = window.location.hash.split("?");
  if (hashParts.length > 1) {
    const hp = new URLSearchParams(hashParts[1]);
    if (hp.has("edit")) return hp.get("edit");
  }
  return null;
}

export default function AddListing() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { token } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingProperty, setIsLoadingProperty] = useState(false);
  const [uploadingCount, setUploadingCount] = useState(0);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[]>>({});
  const [images, setImages] = useState<string[]>([]);
  const [videos, setVideos] = useState<string[]>([]);
  const [videoLimit, setVideoLimit] = useState(0);
  const [uploadingVideoCount, setUploadingVideoCount] = useState(0);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const [isLocationPinned, setIsLocationPinned] = useState(false);
  const [isMapModalOpen, setIsMapModalOpen] = useState(false);
  const [pinPosition, setPinPosition] = useState<google.maps.LatLngLiteral | null>(null);
  const [draftPin, setDraftPin] = useState<google.maps.LatLngLiteral | null>(null);
  const [draftAddress, setDraftAddress] = useState("");

  const { isLoaded: mapsLoaded } = useJsApiLoader({ googleMapsApiKey: GOOGLE_API_KEY, libraries: GOOGLE_MAPS_LIBRARIES });

  const mapRef = useRef<google.maps.Map | null>(null);
  const searchBoxRef = useRef<google.maps.places.SearchBox | null>(null);

  const handlePlacesChanged = useCallback(() => {
    const places = searchBoxRef.current?.getPlaces();
    if (!places || places.length === 0) return;
    const place = places[0];
    const loc = place.geometry?.location;
    if (!loc) return;
    const pos = { lat: loc.lat(), lng: loc.lng() };
    setDraftPin(pos);
    setDraftAddress(place.formatted_address ?? place.name ?? "");
    mapRef.current?.panTo(pos);
    mapRef.current?.setZoom(15);
  }, []);

  const reverseGeocodeDraft = useCallback((pos: google.maps.LatLngLiteral) => {
    if (!window.google) return;
    new google.maps.Geocoder().geocode({ location: pos }, (results, status) => {
      if (status === "OK" && results && results[0]) {
        setDraftAddress(results[0].formatted_address);
      }
    });
  }, []);

  useEffect(() => {
    if (isMapModalOpen) {
      setDraftPin(pinPosition);
      setDraftAddress(address || searchQuery);
    }
  }, [isMapModalOpen]);

  const [searchQuery, setSearchQuery] = useState("Nairobi, Kenya");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const dragSrcRef = useRef<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);

  const { uploadFile } = useUpload({
    onError: (err: Error) => {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
    },
  });

  // Controlled state for Select fields
  const [listingType, setListingType] = useState("");
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [address, setAddress] = useState("");
  const [beds, setBeds] = useState("");
  const [baths, setBaths] = useState("");
  const [sqft, setSqft] = useState("");
  const [description, setDescription] = useState("");
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [subtype, setSubtype] = useState("");
  const [hourlyRate, setHourlyRate] = useState("");

  const toggleAmenity = (id: string) => {
    setSelectedAmenities(prev =>
      prev.includes(id) ? prev.filter(a => a !== id) : [...prev, id]
    );
  };

  const editId = getEditId();
  const isEditing = editId !== null;

  // Fetch subscription to determine video limit
  useEffect(() => {
    if (!token) return;
    fetch("/api/subscriptions/me", { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then((data: { videoLimit?: number }) => {
        setVideoLimit(typeof data.videoLimit === "number" ? data.videoLimit : 0);
      })
      .catch(() => {});
  }, [token]);

  // Fetch existing property data when in edit mode
  useEffect(() => {
    if (!editId || !token) return;
    setIsLoadingProperty(true);
    fetch(`/api/properties/${editId}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(res => {
        if (!res.ok) throw new Error("Property not found");
        return res.json();
      })
      .then((prop: { title: string; type: string; price: number; address: string; beds: number; baths: number; sqft: number; image?: string; images?: string[]; videos?: string[]; description?: string; tags?: string[]; subtype?: string; hourlyRate?: number }) => {
        setTitle(prop.title ?? "");
        setListingType(prop.type ?? "");
        setPrice(prop.price != null ? String(prop.price) : "");
        setAddress(prop.address ?? "");
        setBeds(prop.beds != null ? String(prop.beds) : "");
        setBaths(prop.baths != null ? String(prop.baths) : "");
        setSqft(prop.sqft != null ? String(prop.sqft) : "");
        setDescription(prop.description ?? "");
        if (prop.images && prop.images.length > 0) {
          setImages(prop.images);
        } else if (prop.image) {
          setImages([prop.image]);
        }
        if (prop.videos && prop.videos.length > 0) setVideos(prop.videos);
        if (prop.tags) setSelectedAmenities(prop.tags);
        if (prop.subtype) setSubtype(prop.subtype);
        if (prop.hourlyRate != null) setHourlyRate(String(prop.hourlyRate));
      })
      .catch(() => {
        toast({ title: "Could not load property", description: "The property could not be fetched for editing.", variant: "destructive" });
      })
      .finally(() => setIsLoadingProperty(false));
  }, [editId, token]);

  const uploadImageFiles = useCallback(async (files: File[]) => {
    if (files.length === 0) return;
    setUploadingCount(prev => prev + files.length);
    const results = await Promise.all(
      files.map(async (file) => {
        const result = await uploadFile(file);
        return result?.objectPath ?? null;
      })
    );
    const uploaded = (results as (string | null)[]).filter((p): p is string => p !== null);
    if (uploaded.length < files.length) {
      toast({ title: "Some uploads failed", description: "One or more photos could not be uploaded.", variant: "destructive" });
    }
    if (uploaded.length > 0) {
      setImages(prev => [...prev, ...uploaded]);
    }
    setUploadingCount(prev => prev - files.length);
  }, [uploadFile, toast]);

  const handleImageUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const fileArray = Array.from(files);
    e.target.value = "";
    await uploadImageFiles(fileArray);
  }, [uploadImageFiles]);

  const handleUploadZoneDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith("image/"));
    await uploadImageFiles(files);
  }, [uploadImageFiles]);

  const moveImage = useCallback((from: number, direction: -1 | 1) => {
    const to = from + direction;
    setImages(prev => {
      if (to < 0 || to >= prev.length) return prev;
      const next = [...prev];
      [next[from], next[to]] = [next[to], next[from]];
      return next;
    });
  }, []);

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const removeVideo = (index: number) => {
    setVideos(prev => prev.filter((_, i) => i !== index));
  };

  const handleVideoUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const fileArray = Array.from(files);
    e.target.value = "";

    const remaining = videoLimit - videos.length;
    if (remaining <= 0) {
      toast({ title: "Video limit reached", description: `Your plan allows ${videoLimit} video${videoLimit === 1 ? "" : "s"} per listing.`, variant: "destructive" });
      return;
    }
    const toUpload = fileArray.slice(0, remaining);
    if (toUpload.length < fileArray.length) {
      toast({ title: "Too many videos", description: `Only ${remaining} slot${remaining === 1 ? "" : "s"} remaining. Extra files skipped.`, variant: "destructive" });
    }

    // Validate each video is ≤30 seconds
    const validFiles: File[] = [];
    for (const file of toUpload) {
      const duration = await new Promise<number>((resolve) => {
        const vid = document.createElement("video");
        vid.preload = "metadata";
        vid.onloadedmetadata = () => { URL.revokeObjectURL(vid.src); resolve(vid.duration); };
        vid.onerror = () => { URL.revokeObjectURL(vid.src); resolve(Infinity); };
        vid.src = URL.createObjectURL(file);
      });
      if (duration > 30) {
        toast({ title: "Video too long", description: `"${file.name}" is longer than 30 seconds and was skipped.`, variant: "destructive" });
      } else {
        validFiles.push(file);
      }
    }

    if (validFiles.length === 0) return;
    setUploadingVideoCount(prev => prev + validFiles.length);
    const results = await Promise.all(validFiles.map(f => uploadFile(f).catch(() => null)));
    const uploaded = results
      .map(r => (r && typeof r === "object" && "objectPath" in r ? r.objectPath : null))
      .filter((p): p is string => p !== null);
    if (uploaded.length < validFiles.length) {
      toast({ title: "Some uploads failed", description: "One or more videos could not be uploaded.", variant: "destructive" });
    }
    if (uploaded.length > 0) {
      setVideos(prev => [...prev, ...uploaded]);
    }
    setUploadingVideoCount(prev => prev - validFiles.length);
  }, [uploadFile, toast, videoLimit, videos.length]);

  const handleDragStart = (index: number) => {
    dragSrcRef.current = index;
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    setDragOverIndex(index);
  };

  const handleDrop = (e: React.DragEvent, dropIndex: number) => {
    e.preventDefault();
    const srcIndex = dragSrcRef.current;
    if (srcIndex === null || srcIndex === dropIndex) {
      dragSrcRef.current = null;
      setDragOverIndex(null);
      return;
    }
    setImages(prev => {
      const next = [...prev];
      const [moved] = next.splice(srcIndex, 1);
      next.splice(dropIndex, 0, moved);
      return next;
    });
    dragSrcRef.current = null;
    setDragOverIndex(null);
  };

  const handleDragEnd = () => {
    dragSrcRef.current = null;
    setDragOverIndex(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) {
      toast({ title: "Sign in required", description: "Please sign in to add a listing.", variant: "destructive" });
      return;
    }
    if (!listingType) {
      toast({ title: "Missing field", description: "Please select a listing type.", variant: "destructive" });
      return;
    }
    if (uploadingCount > 0) {
      toast({ title: "Upload in progress", description: "Please wait for all photos to finish uploading.", variant: "destructive" });
      return;
    }

    const parsedPrice = parseInt(price, 10);
    const parsedBeds = parseInt(beds, 10);
    const parsedBaths = parseInt(baths, 10);
    const parsedSqft = parseInt(sqft, 10);

    const clientErrors: Record<string, string[]> = {};
    if (!title.trim()) clientErrors.title = ["Title is required"];
    if (isNaN(parsedPrice) || parsedPrice <= 0) clientErrors.price = ["Price must be greater than 0"];
    if (!address.trim() && !searchQuery.trim()) clientErrors.address = ["Address is required"];
    if (!isNaN(parsedBeds) && parsedBeds < 0) clientErrors.beds = ["Bedrooms cannot be negative"];
    if (!isNaN(parsedBaths) && parsedBaths < 0) clientErrors.baths = ["Bathrooms cannot be negative"];

    if (Object.keys(clientErrors).length > 0) {
      setFieldErrors(clientErrors);
      toast({ title: "Please fix the errors below", variant: "destructive" });
      return;
    }

    setFieldErrors({});
    setIsSubmitting(true);
    try {
      const body = {
        title,
        type: toApiType(listingType),
        price: parsedPrice,
        address: address || searchQuery,
        beds: isNaN(parsedBeds) ? 0 : parsedBeds,
        baths: isNaN(parsedBaths) ? 0 : parsedBaths,
        sqft: isNaN(parsedSqft) ? 0 : parsedSqft,
        description: description || null,
        images,
        videos,
        tags: selectedAmenities,
        subtype: subtype || undefined,
        hourlyRate: (listingType === "bnb" && hourlyRate) ? parseInt(hourlyRate, 10) : undefined,
        lat: pinPosition?.lat != null ? String(pinPosition.lat) : undefined,
        lng: pinPosition?.lng != null ? String(pinPosition.lng) : undefined,
      };

      const url = isEditing ? `/api/properties/${editId}` : "/api/properties";
      const method = isEditing ? "PATCH" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({})) as { error?: string; details?: { fieldErrors?: Record<string, string[]> } };
        if (data.details?.fieldErrors && Object.keys(data.details.fieldErrors).length > 0) {
          setFieldErrors(data.details.fieldErrors);
          toast({
            title: isEditing ? "Update failed" : "Submission failed",
            description: "Please fix the highlighted errors below.",
            variant: "destructive",
          });
        } else {
          toast({
            title: isEditing ? "Update failed" : "Submission failed",
            description: data.error || "Could not submit listing. Please try again.",
            variant: "destructive",
          });
        }
        return;
      }
      setFieldErrors({});
      toast({
        title: isEditing ? "Listing Updated" : "Listing Submitted for Review",
        description: isEditing
          ? "Your property has been updated."
          : "Your listing has been submitted and is pending admin approval before it goes live.",
      });
      setLocation("/dashboard");
    } catch {
      toast({ title: "Network error", description: "Could not reach the server. Please try again.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoadingProperty) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 py-8 flex items-center justify-center">
          <p className="text-muted-foreground">Loading property details...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-12">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold font-heading">{isEditing ? "Edit Listing" : "Add New Listing"}</h1>
            <p className="text-muted-foreground">{isEditing ? "Update your property details below." : "Fill in the details below to publish your property. Admin approval is required before the listing goes live."}</p>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="space-y-6">
              {/* Basic Info */}
              <Card>
                <CardHeader>
                  <CardTitle>Property Details</CardTitle>
                  <CardDescription>The basics about your property</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Property Title</Label>
                    <Input id="title" placeholder="e.g. Modern Apartment in Westlands" value={title} onChange={e => { setTitle(e.target.value); setFieldErrors(prev => ({ ...prev, title: [] })); }} required className={fieldErrors.title?.length ? "border-red-500" : ""} />
                    {fieldErrors.title?.map(err => <p key={err} className="text-xs text-red-500">{err}</p>)}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="type">Listing Type</Label>
                      <Select value={listingType} onValueChange={setListingType} required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="rent">For Rent</SelectItem>
                          <SelectItem value="rent-business">For Rent - Business Space</SelectItem>
                          <SelectItem value="rent-godown">For Rent - Godown</SelectItem>
                          <SelectItem value="rent-stall">For Rent - Stall</SelectItem>
                          <SelectItem value="rent-shop">For Rent - Shop</SelectItem>
                          <SelectItem value="sale">For Sale</SelectItem>
                          <SelectItem value="bnb">B&B / Short Stay</SelectItem>
                          <SelectItem value="hotel">Hotel</SelectItem>
                          <SelectItem value="hostel">Hostel (Student Rentals)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {listingType !== 'bnb' && (
                    <div className="space-y-2">
                      <Label htmlFor="price">Price (KES)</Label>
                      <Input id="price" type="number" placeholder="e.g. 85000" value={price} onChange={e => { setPrice(e.target.value); setFieldErrors(prev => ({ ...prev, price: [] })); }} required className={fieldErrors.price?.length ? "border-red-500" : ""} />
                      {fieldErrors.price?.map(err => <p key={err} className="text-xs text-red-500">{err}</p>)}
                    </div>
                    )}
                  </div>

                  {/* Subtype selector — Rent: apartment category; Sale: property category */}
                  {(listingType === 'rent') && (
                  <div className="space-y-2">
                    <Label htmlFor="subtype">Apartment Type</Label>
                    <Select value={subtype} onValueChange={setSubtype}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select apartment type (optional)" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="studio">Studio / Bedsitter</SelectItem>
                        <SelectItem value="1-bedroom">1 Bedroom</SelectItem>
                        <SelectItem value="2-bedroom">2 Bedrooms</SelectItem>
                        <SelectItem value="3-bedroom">3 Bedrooms</SelectItem>
                        <SelectItem value="4-bedroom">4+ Bedrooms</SelectItem>
                        <SelectItem value="penthouse">Penthouse</SelectItem>
                        <SelectItem value="own-compound">Own Compound</SelectItem>
                        <SelectItem value="condominium">Condominium</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">Helps guests find your property under the right category.</p>
                  </div>
                  )}

                  {listingType === 'sale' && (
                  <div className="space-y-2">
                    <Label htmlFor="subtype">Property Category</Label>
                    <Select value={subtype} onValueChange={setSubtype}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category (optional)" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="apartment">Apartment</SelectItem>
                        <SelectItem value="home">Home / House</SelectItem>
                        <SelectItem value="land">Land</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">Helps buyers filter by property category.</p>
                  </div>
                  )}

                  {/* BnB Type selector */}
                  {listingType === 'bnb' && (
                  <div className="space-y-3">
                    <Label htmlFor="bnb_subtype">B&B Property Type</Label>
                    <Select value={subtype} onValueChange={setSubtype}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select B&B type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="serviced-apartment">
                          <div>
                            <div className="font-medium">Serviced Apartment</div>
                            <div className="text-xs text-muted-foreground">Fully furnished with hotel-like amenities</div>
                          </div>
                        </SelectItem>
                        <SelectItem value="entire-place">
                          <div>
                            <div className="font-medium">Entire Place</div>
                            <div className="text-xs text-muted-foreground">Private home, apartment or villa with dedicated entrance</div>
                          </div>
                        </SelectItem>
                        <SelectItem value="private-room">
                          <div>
                            <div className="font-medium">Private Room</div>
                            <div className="text-xs text-muted-foreground">Own bedroom; shared kitchen, living room or bathroom</div>
                          </div>
                        </SelectItem>
                        <SelectItem value="shared-room">
                          <div>
                            <div className="font-medium">Shared Room</div>
                            <div className="text-xs text-muted-foreground">Shared bedroom and common areas with other guests</div>
                          </div>
                        </SelectItem>
                        <SelectItem value="unique-stays">
                          <div>
                            <div className="font-medium">Unique Stays</div>
                            <div className="text-xs text-muted-foreground">Treehouses, container homes, yurts, houseboats and more</div>
                          </div>
                        </SelectItem>
                        <SelectItem value="hotel-room">
                          <div>
                            <div className="font-medium">Hotel Room / Boutique Hotel</div>
                            <div className="text-xs text-muted-foreground">Rooms in hotels, hostels or Bed & Breakfasts</div>
                          </div>
                        </SelectItem>
                        <SelectItem value="vacation-home">
                          <div>
                            <div className="font-medium">Vacation Home</div>
                            <div className="text-xs text-muted-foreground">Cabins, rustic villas or standalone getaway properties</div>
                          </div>
                        </SelectItem>
                        <SelectItem value="nature-stay">
                          <div>
                            <div className="font-medium">Nature-Focused Stay</div>
                            <div className="text-xs text-muted-foreground">Cabins, bungalows, container homes, villas in nature settings</div>
                          </div>
                        </SelectItem>
                        <SelectItem value="other">
                          <div>
                            <div className="font-medium">Other</div>
                            <div className="text-xs text-muted-foreground">Any other type of short-stay accommodation</div>
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">Helps guests understand what kind of stay they are booking.</p>
                  </div>
                  )}

                  {/* BnB Pricing — daily (existing price) + optional hourly rate */}
                  {listingType === 'bnb' && (
                  <div className="space-y-3 p-4 bg-blue-50 rounded-lg border border-blue-100">
                    <div>
                      <Label className="text-sm font-semibold text-blue-800">B&B Pricing Options</Label>
                      <p className="text-xs text-muted-foreground mt-0.5">Set daily rate, hourly rate, or both.</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <Label htmlFor="price_bnb" className="text-sm">Daily Rate (KES)</Label>
                        <Input id="price_bnb" type="number" min="0" placeholder="e.g. 5000" value={price} onChange={e => { setPrice(e.target.value); setFieldErrors(prev => ({ ...prev, price: [] })); }} />
                        <p className="text-xs text-muted-foreground">Price per night/day</p>
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="hourly_rate" className="text-sm">Hourly Rate (KES) <span className="text-gray-400 font-normal">(optional)</span></Label>
                        <Input id="hourly_rate" type="number" min="0" placeholder="e.g. 800" value={hourlyRate} onChange={e => setHourlyRate(e.target.value)} />
                        <p className="text-xs text-muted-foreground">Leave blank if hourly is not available</p>
                      </div>
                    </div>
                  </div>
                  )}

                  {listingType === 'hostel' && (
                  <div className="space-y-2">
                    <Label htmlFor="payment_term">Payment Term</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select payment term" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="monthly">Per Month</SelectItem>
                        <SelectItem value="quarterly">For 3 Months (Quarterly)</SelectItem>
                        <SelectItem value="yearly">Per Year</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">Select the required payment term so students know when they book.</p>
                  </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="address">Full Address</Label>
                    <Input id="address" placeholder="e.g. 123 Peponi Road, Westlands, Nairobi" value={address} onChange={e => { setAddress(e.target.value); setFieldErrors(prev => ({ ...prev, address: [] })); }} required className={fieldErrors.address?.length ? "border-red-500" : ""} />
                    {fieldErrors.address?.map(err => <p key={err} className="text-xs text-red-500">{err}</p>)}
                  </div>

                  <div className="space-y-2">
                    <Label>Map Location (Pin)</Label>
                    <div className="text-sm text-gray-500 mb-2">Set the exact location of your property on the map. This helps guests find your property easily.</div>
                    <div 
                      className={`bg-gray-100 rounded-lg h-[200px] border flex flex-col items-center justify-center relative overflow-hidden group cursor-pointer transition-colors ${isLocationPinned ? 'border-green-500' : 'border-gray-200'}`}
                      onClick={() => setIsMapModalOpen(true)}
                    >
                      <img src="/images/modern_apartment_exterior.png" className="absolute inset-0 w-full h-full object-cover opacity-30 blur-sm" />
                      <div className="relative z-10 flex flex-col items-center bg-white/90 p-4 rounded-lg shadow-sm">
                        {isLocationPinned ? (
                          <>
                            <Check className="h-8 w-8 text-green-500 mb-2" />
                            <span className="font-medium text-sm text-green-600">Location Pinned! Click to edit</span>
                          </>
                        ) : (
                          <>
                            <MapPin className="h-8 w-8 text-primary mb-2" />
                            <span className="font-medium text-sm">Click to set exact pin location</span>
                          </>
                        )}
                      </div>
                      <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Specs */}
              <Card>
                <CardHeader>
                  <CardTitle>Features & Amenities</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="beds">Bedrooms</Label>
                      <Input id="beds" type="number" min="0" value={beds} onChange={e => { setBeds(e.target.value); setFieldErrors(prev => ({ ...prev, beds: [] })); }} required className={fieldErrors.beds?.length ? "border-red-500" : ""} />
                      {fieldErrors.beds?.map(err => <p key={err} className="text-xs text-red-500">{err}</p>)}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="baths">Bathrooms</Label>
                      <Input id="baths" type="number" min="0" value={baths} onChange={e => { setBaths(e.target.value); setFieldErrors(prev => ({ ...prev, baths: [] })); }} required className={fieldErrors.baths?.length ? "border-red-500" : ""} />
                      {fieldErrors.baths?.map(err => <p key={err} className="text-xs text-red-500">{err}</p>)}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="sqft">Square Ft</Label>
                      <Input id="sqft" type="number" min="0" value={sqft} onChange={e => { setSqft(e.target.value); setFieldErrors(prev => ({ ...prev, sqft: [] })); }} className={fieldErrors.sqft?.length ? "border-red-500" : ""} />
                      {fieldErrors.sqft?.map(err => <p key={err} className="text-xs text-red-500">{err}</p>)}
                    </div>
                  </div>
                  
                  {/* Unit Amenities */}
                  <div className="space-y-3">
                    <div>
                      <Label className="text-sm font-semibold">Unit Amenities</Label>
                      <p className="text-xs text-muted-foreground mt-0.5">Features inside the individual unit/room</p>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 p-4 bg-gray-50 rounded-lg border">
                      {UNIT_AMENITIES.map((item) => (
                        <div key={item.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={`amenity-${item.id}`}
                            checked={selectedAmenities.includes(item.id)}
                            onCheckedChange={() => toggleAmenity(item.id)}
                          />
                          <label
                            htmlFor={`amenity-${item.id}`}
                            className="text-sm leading-none cursor-pointer peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            {item.label}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Premise Amenities */}
                  <div className="space-y-3">
                    <div>
                      <Label className="text-sm font-semibold">Premise Amenities</Label>
                      <p className="text-xs text-muted-foreground mt-0.5">Shared facilities available on the property</p>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 p-4 bg-gray-50 rounded-lg border">
                      {PREMISE_AMENITIES.map((item) => (
                        <div key={item.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={`amenity-${item.id}`}
                            checked={selectedAmenities.includes(item.id)}
                            onCheckedChange={() => toggleAmenity(item.id)}
                          />
                          <label
                            htmlFor={`amenity-${item.id}`}
                            className="text-sm leading-none cursor-pointer peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            {item.label}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea 
                      id="description" 
                      placeholder="Describe the property features, neighborhood, etc." 
                      className="min-h-[150px]"
                      value={description}
                      onChange={e => setDescription(e.target.value)}
                      required 
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Photos */}
              <Card>
                <CardHeader>
                  <CardTitle>Photos</CardTitle>
                  <CardDescription>Upload or take high quality images of your property</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4 mb-4">
                    <div
                      className="relative flex-1 border-2 border-dashed border-gray-200 rounded-lg p-6 text-center hover:bg-gray-50 active:bg-gray-100 transition-colors cursor-pointer flex flex-col items-center justify-center gap-2"
                      onDragOver={e => e.preventDefault()}
                      onDrop={handleUploadZoneDrop}
                    >
                      <div className="h-10 w-10 bg-primary/10 rounded-full flex items-center justify-center text-primary pointer-events-none">
                        <Upload className="h-5 w-5" />
                      </div>
                      <h3 className="font-semibold text-sm pointer-events-none">Upload Photos</h3>
                      <p className="text-xs text-muted-foreground pointer-events-none">Tap to browse or drag files here</p>
                      <input
                        type="file"
                        multiple
                        accept="image/*"
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        ref={fileInputRef}
                        onChange={handleImageUpload}
                      />
                    </div>

                    <div
                      className="relative flex-1 border-2 border-dashed border-gray-200 rounded-lg p-6 text-center hover:bg-gray-50 active:bg-gray-100 transition-colors cursor-pointer flex flex-col items-center justify-center gap-2"
                    >
                      <div className="h-10 w-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 pointer-events-none">
                        <Camera className="h-5 w-5" />
                      </div>
                      <h3 className="font-semibold text-sm pointer-events-none">Take Photo</h3>
                      <p className="text-xs text-muted-foreground pointer-events-none">Open camera</p>
                      <input
                        type="file"
                        accept="image/*"
                        capture="environment"
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        ref={cameraInputRef}
                        onChange={handleImageUpload}
                      />
                    </div>
                  </div>
                  
                  {(images.length > 0 || uploadingCount > 0) ? (
                    <>
                      {images.length > 1 && (
                        <p className="text-xs text-muted-foreground mb-2 mt-4 flex items-center gap-1">
                          <GripVertical className="h-3 w-3" /> Drag to reorder on desktop · use arrows on mobile. First photo is the cover.
                        </p>
                      )}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-2">
                      {images.map((img, i) => (
                        <div
                          key={img}
                          draggable
                          onDragStart={() => handleDragStart(i)}
                          onDragOver={e => handleDragOver(e, i)}
                          onDrop={e => handleDrop(e, i)}
                          onDragEnd={handleDragEnd}
                          className={`relative aspect-square bg-gray-100 rounded-lg overflow-hidden group cursor-grab active:cursor-grabbing transition-all ${dragOverIndex === i && dragSrcRef.current !== i ? "ring-2 ring-primary scale-105" : ""}`}
                        >
                          <img src={getImageDisplayUrl(img)} alt={`Photo ${i + 1}`} className="w-full h-full object-cover pointer-events-none" />
                          {i === 0 && (
                            <span className="absolute bottom-1 left-1 bg-primary text-white text-[10px] font-semibold px-1.5 py-0.5 rounded">Cover</span>
                          )}
                          <button
                            type="button"
                            onClick={() => removeImage(i)}
                            className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full shadow-md"
                          >
                            <X className="h-3 w-3" />
                          </button>
                          {images.length > 1 && (
                            <div className="absolute bottom-1 right-1 flex gap-0.5">
                              {i > 0 && (
                                <button
                                  type="button"
                                  onClick={() => moveImage(i, -1)}
                                  className="bg-black/60 text-white rounded px-1 py-0.5 text-[10px] font-bold leading-none hover:bg-black/80"
                                  title="Move left"
                                >←</button>
                              )}
                              {i < images.length - 1 && (
                                <button
                                  type="button"
                                  onClick={() => moveImage(i, 1)}
                                  className="bg-black/60 text-white rounded px-1 py-0.5 text-[10px] font-bold leading-none hover:bg-black/80"
                                  title="Move right"
                                >→</button>
                              )}
                            </div>
                          )}
                        </div>
                      ))}
                      {Array.from({ length: uploadingCount }).map((_, i) => (
                        <div key={`uploading-${i}`} className="relative aspect-square bg-gray-100 rounded-lg flex items-center justify-center">
                          <Loader2 className="h-6 w-6 animate-spin text-primary" />
                          <span className="sr-only">Uploading…</span>
                        </div>
                      ))}
                    </div>
                    </>
                  ) : (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4 opacity-50">
                      {[1, 2, 3, 4].map(i => (
                        <div key={i} className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center text-gray-400">
                          <ImageIcon className="h-6 w-6" />
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Videos */}
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <CardTitle>Property Videos</CardTitle>
                      <CardDescription>
                        {videoLimit === 0
                          ? "Video upload requires a Silver or Gold plan"
                          : `Upload up to ${videoLimit} video${videoLimit === 1 ? "" : "s"}, max 30 seconds each`}
                      </CardDescription>
                    </div>
                    {videoLimit === 0 && (
                      <a href="#/pricing" className="text-xs text-primary underline underline-offset-2 shrink-0 mt-1">Upgrade plan</a>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {videoLimit === 0 ? (
                    <div className="flex items-center gap-3 rounded-lg bg-amber-50 border border-amber-200 px-4 py-3 text-sm text-amber-800">
                      <AlertCircle className="h-4 w-4 shrink-0" />
                      Your Standard plan does not include property videos. Upgrade to Silver (1 video) or Gold (2 videos) to unlock this feature.
                    </div>
                  ) : (
                    <>
                      {videos.length < videoLimit && (
                        <div
                          className={`relative border-2 border-dashed border-gray-200 rounded-lg p-6 text-center hover:bg-gray-50 transition-colors cursor-pointer flex flex-col items-center justify-center gap-2 ${uploadingVideoCount > 0 ? "opacity-50 pointer-events-none" : ""}`}
                        >
                          <div className="h-10 w-10 bg-primary/10 rounded-full flex items-center justify-center text-primary pointer-events-none">
                            <Video className="h-5 w-5" />
                          </div>
                          <h3 className="font-semibold text-sm pointer-events-none">Upload Video</h3>
                          <p className="text-xs text-muted-foreground pointer-events-none">{videos.length}/{videoLimit} used · max 30 seconds</p>
                          <input
                            type="file"
                            accept="video/*"
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                            ref={videoInputRef}
                            onChange={handleVideoUpload}
                          />
                        </div>
                      )}

                      {(videos.length > 0 || uploadingVideoCount > 0) && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                          {videos.map((url, i) => (
                            <div key={url} className="relative rounded-lg overflow-hidden bg-black group">
                              <video
                                src={url.startsWith("/objects/") ? `/api/storage${url}` : url}
                                className="w-full aspect-video object-cover"
                                controls
                                preload="metadata"
                              />
                              <button
                                type="button"
                                onClick={() => removeVideo(i)}
                                className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <X className="h-4 w-4" />
                              </button>
                              <span className="absolute bottom-2 left-2 bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded">Video {i + 1}</span>
                            </div>
                          ))}
                          {Array.from({ length: uploadingVideoCount }).map((_, i) => (
                            <div key={`uploading-video-${i}`} className="relative aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
                              <Loader2 className="h-6 w-6 animate-spin text-primary" />
                              <span className="sr-only">Uploading…</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </>
                  )}
                </CardContent>
              </Card>

              <div className="flex gap-4 justify-end">
                <Button variant="outline" type="button" onClick={() => setLocation("/dashboard")}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-primary" disabled={isSubmitting || uploadingCount > 0 || uploadingVideoCount > 0}>
                  {uploadingCount > 0 || uploadingVideoCount > 0 ? (
                    <span className="flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Uploading media…</span>
                  ) : isSubmitting ? (
                    isEditing ? "Updating..." : "Submitting..."
                  ) : (
                    isEditing ? "Update Property" : <span className="flex items-center gap-2"><Check className="h-4 w-4" /> Submit for Approval</span>
                  )}
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>

      <Dialog open={isMapModalOpen} onOpenChange={setIsMapModalOpen}>
        <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden">
          <DialogHeader className="p-4 bg-white border-b">
            <DialogTitle>Pin Property Location</DialogTitle>
            <DialogDescription>
              Click the map to drop a pin. Drag the pin to fine-tune the position.
            </DialogDescription>
          </DialogHeader>
          <div className="relative h-[400px] w-full overflow-hidden">
            {mapsLoaded ? (
              <>
                <StandaloneSearchBox
                  onLoad={(ref) => { searchBoxRef.current = ref; }}
                  onPlacesChanged={handlePlacesChanged}
                >
                  <div className="absolute top-3 left-3 right-3 z-10">
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="Search for a neighbourhood or address…"
                        className="w-full rounded-md border border-gray-300 bg-white py-2 pl-9 pr-3 text-sm shadow-md focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                      <MapPin className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400 pointer-events-none" />
                    </div>
                  </div>
                </StandaloneSearchBox>
                <GoogleMap
                  mapContainerClassName="w-full h-full"
                  center={draftPin ?? NAIROBI_CENTER}
                  zoom={13}
                  options={{ mapId: "c7cd60c6a53a720a14502d1b", mapTypeControl: false, streetViewControl: false, fullscreenControl: false }}
                  onLoad={(map) => { mapRef.current = map; }}
                  onClick={(e) => {
                    if (e.latLng) {
                      const pos = { lat: e.latLng.lat(), lng: e.latLng.lng() };
                      setDraftPin(pos);
                      reverseGeocodeDraft(pos);
                    }
                  }}
                >
                  {draftPin && (
                    <AdvancedMarker
                      position={draftPin}
                      draggable
                      onDragEnd={(e) => {
                        if (e.latLng) {
                          const pos = { lat: e.latLng.lat(), lng: e.latLng.lng() };
                          setDraftPin(pos);
                          reverseGeocodeDraft(pos);
                        }
                      }}
                    />
                  )}
                </GoogleMap>
              </>
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gray-100">
                <Loader2 className="h-6 w-6 animate-spin text-gray-400" />
              </div>
            )}
            {draftPin && draftAddress && (
              <div className="absolute bottom-4 left-4 right-4 z-30 bg-white rounded-md shadow-lg px-3 py-2 flex items-center gap-2">
                <MapPin className="h-4 w-4 text-primary shrink-0" />
                <span className="text-sm text-gray-700 truncate">{draftAddress}</span>
              </div>
            )}
            {!draftPin && (
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-30 pointer-events-none text-center">
                <div className="bg-white/90 rounded-lg shadow px-4 py-2 text-sm text-gray-600">
                  Click anywhere on the map to pin your property
                </div>
              </div>
            )}
          </div>
          <div className="p-4 bg-white border-t flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsMapModalOpen(false)}>Cancel</Button>
            <Button
              className="bg-primary"
              disabled={!draftPin}
              onClick={() => {
                setPinPosition(draftPin);
                if (draftAddress) {
                  setAddress(draftAddress);
                  setSearchQuery(draftAddress);
                }
                setIsLocationPinned(true);
                setIsMapModalOpen(false);
                toast({
                  title: "Location Saved",
                  description: "Your property location has been pinned.",
                });
              }}
            >
              Confirm Location
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}