// app.config.js — dynamic Expo config
// Edit API_URL below to point to your deployed INNDOS backend.
// This value is bundled into the app at build time.

const API_URL = process.env.EXPO_PUBLIC_API_URL || "https://inndos.com";

/** @type {import('expo/config').ExpoConfig} */
const config = {
  name: "INNDOS Mobile",
  slug: "inndos-mobile",
  version: "1.0.0",
  orientation: "portrait",
  icon: "./assets/images/icon.png",
  scheme: "inndos",
  userInterfaceStyle: "automatic",
  newArchEnabled: true,
  splash: {
    image: "./assets/images/icon.png",
    resizeMode: "contain",
    backgroundColor: "#0a0a0a",
  },
  ios: {
    supportsTablet: false,
    bundleIdentifier: "com.inndos.app",
    icon: "./assets/images/icon.png",
  },
  android: {
    adaptiveIcon: {
      foregroundImage: "./assets/images/icon.png",
      backgroundColor: "#0a0a0a",
    },
    icon: "./assets/images/icon.png",
    package: "com.inndos.app",
  },
  web: {
    favicon: "./assets/images/icon.png",
  },
  plugins: ["expo-router", "expo-font", "expo-web-browser", "expo-location"],
  experiments: {
    typedRoutes: true,
  },
  extra: {
    // This value is available at runtime via Constants.expoConfig.extra.apiUrl
    apiUrl: API_URL,
  },
};

module.exports = config;
