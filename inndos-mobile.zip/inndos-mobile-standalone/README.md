# INNDOS Mobile

React Native / Expo app for the INNDOS property platform.

## Prerequisites

- Node.js 20+
- npm or yarn
- Expo CLI: `npm install -g expo-cli`
- EAS CLI (for cloud builds): `npm install -g eas-cli`
- An [Expo account](https://expo.dev) (free)
- An Apple Developer account (for iOS App Store distribution)

---

## Setup

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment

```bash
cp .env.example .env
```

Edit `.env` and set `EXPO_PUBLIC_API_URL` to your deployed backend URL:

```
EXPO_PUBLIC_API_URL=https://inndos.com
```

### 3. Run locally (Expo Go)

```bash
npx expo start
```

Scan the QR code with the **Expo Go** app on your phone.

---

## Build for iOS with EAS (expo.dev)

### 1. Log in to EAS

```bash
eas login
```

### 2. Link to your Expo project

```bash
eas init
```

This creates an `extra.eas.projectId` in `app.json`. Commit the updated file.

### 3. Set your API URL in eas.json

Edit `eas.json` → replace `https://your-api-domain.com` with your real backend URL in all three build profiles.

### 4. Start an iOS build

```bash
# Internal TestFlight / Ad Hoc build
eas build --platform ios --profile preview

# Production App Store build
eas build --platform ios --profile production
```

Monitor the build at https://expo.dev/builds.

### 5. Submit to App Store (optional)

```bash
eas submit --platform ios --profile production
```

---

## Project structure

```
api-client/          Local copy of the typed API client (auto-generated)
app/                 Expo Router screens
  (auth)/            Login & signup screens
  (tabs)/            Main tab screens (Browse, Search, Saved, Bookings, …)
  property/[id].tsx  Property detail screen
  booking/[id].tsx   Booking confirmation screen
assets/              Images & icons
components/          Shared UI components
constants/           Design tokens (colors, etc.)
context/             React context providers (Auth)
hooks/               Custom hooks
utils/               Helper utilities
```

---

## Notes

- The `api-client/` folder is a self-contained copy of the typed API client.
  It mirrors your backend's OpenAPI spec. If you update the backend routes,
  re-generate this folder from the OpenAPI spec using orval.
- For map features (property location view), a Google Maps API key is needed
  on Android. Add it to `app.json` under `android.config.googleMaps.apiKey`.
